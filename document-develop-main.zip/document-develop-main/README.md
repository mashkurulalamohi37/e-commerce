# Document & Develop

Nills Mart — beauty & personal care storefront.

## Development

You need Node.js and a package manager (npm, bun, or pnpm).

```sh
git clone <this-repository-url>
cd document-develop
npm i
npm run dev
```

App runs at [http://localhost:8080](http://localhost:8080) by default (check the terminal if the port differs).
