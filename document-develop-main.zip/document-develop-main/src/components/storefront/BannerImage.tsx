import { useState } from "react";
import { cn, resolvePublicUrl } from "@/lib/utils";

/**
 * Banner image with a lightweight shimmer skeleton that stays visible until the
 * image decodes. Native lazy loading everywhere except the LCP slide, which
 * passes priority so it loads eagerly.
 */
export function BannerImage({
  src,
  alt,
  width,
  height,
  priority = false,
  className,
  imgClassName,
}: {
  src: string;
  alt: string;
  width: number;
  height: number;
  priority?: boolean;
  className?: string;
  imgClassName?: string;
}) {
  const [loaded, setLoaded] = useState(false);
  const resolvedSrc = resolvePublicUrl(src);

  return (
    <div className={cn("relative overflow-hidden bg-muted", className)}>
      <div
        aria-hidden
        className={cn(
          "absolute inset-0 skeleton-shimmer transition-opacity duration-300",
          loaded ? "opacity-0" : "opacity-100",
        )}
      />
      <img
        src={resolvedSrc}
        alt={alt}
        width={width}
        height={height}
        loading={priority ? "eager" : "lazy"}
        decoding={priority ? "sync" : "async"}
        fetchPriority={priority ? "high" : "auto"}
        onLoad={() => setLoaded(true)}
        onError={() => setLoaded(true)}
        className={cn(
          "size-full object-cover transition-opacity duration-500",
          loaded ? "opacity-100" : "opacity-0",
          imgClassName,
        )}
      />
    </div>
  );
}
