import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Sparkles, LayoutGrid, ShoppingBag, MessageCircle } from "lucide-react";
import { useCart } from "@/lib/cart";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "Home", icon: Home },
  { to: "/brands", label: "Brands", icon: Sparkles },
  { to: "/categories", label: "Categories", icon: LayoutGrid },
] as const;

export function BottomNav() {
  const { count, setOpen } = useCart();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
      <ul className="mx-auto flex max-w-md items-stretch">
        {items.map(({ to, label, icon: Icon }) => (
          <li key={to} className="flex-1">
            <Link
              to={to}
              className={cn(
                "flex flex-col items-center gap-1 py-2 text-[11px] transition-colors",
                pathname === to ? "text-primary" : "text-muted-foreground",
              )}
            >
              <Icon className="size-5" />
              {label}
            </Link>
          </li>
        ))}
        <li className="flex-1">
          <button
            onClick={() => setOpen(true)}
            className="flex w-full flex-col items-center gap-1 py-2 text-[11px] text-muted-foreground"
          >
            <span className="relative">
              <ShoppingBag className="size-5" />
              {count > 0 && (
                <span className="absolute -right-2 -top-1 grid size-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                  {count}
                </span>
              )}
            </span>
            Cart
          </button>
        </li>
        <li className="flex-1">
          <Link
            to="/help"
            className={cn(
              "flex flex-col items-center gap-1 py-2 text-[11px] transition-colors",
              pathname === "/help" ? "text-primary" : "text-muted-foreground",
            )}
          >
            <MessageCircle className="size-5" />
            Chat
          </Link>
        </li>
      </ul>
    </nav>
  );
}
