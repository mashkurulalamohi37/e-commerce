import { Link } from "@tanstack/react-router";

import acne from "@/assets/concern-acne.jpg";
import antiAging from "@/assets/concern-anti-aging.jpg";
import dandruff from "@/assets/concern-dandruff.jpg";
import drySkin from "@/assets/concern-dry-skin.jpg";
import hairFall from "@/assets/concern-hair-fall.jpg";
import oilControl from "@/assets/concern-oil-control.jpg";
import pore from "@/assets/concern-pore.jpg";
import spot from "@/assets/concern-spot.jpg";
import hairThinning from "@/assets/concern-hair-thinning.jpg";
import sunBurn from "@/assets/concern-sun-burn.jpg";

type Concern = {
  title: string;
  sub: string;
  image: string;
  query: string;
};

const concernTiles: Concern[] = [
  { title: "Acne", sub: "Treatment", image: acne, query: "acne" },
  { title: "Anti Aging", sub: "Treatment", image: antiAging, query: "anti aging" },
  { title: "Dandruff", sub: "Solution", image: dandruff, query: "dandruff" },
  { title: "Dry Skin", sub: "Treatment", image: drySkin, query: "dry skin" },
  { title: "Hair Fall", sub: "Treatment", image: hairFall, query: "hair fall" },
  { title: "Oil Control", sub: "Treatment", image: oilControl, query: "oil control" },
  { title: "Pore", sub: "Care", image: pore, query: "pore" },
  { title: "Spot", sub: "Treatment", image: spot, query: "spot" },
  { title: "Hair Thinning", sub: "Solution", image: hairThinning, query: "hair thinning" },
  { title: "Sun Burn", sub: "Treatment", image: sunBurn, query: "sun" },
];

export function ConcernTiles() {
  return (
    <section className="py-6">
      <h2 className="px-4 text-center font-display text-base font-extrabold uppercase tracking-wide sm:text-lg">
        Shop by Concern
      </h2>

      <div className="mt-4 grid grid-cols-2 gap-3 px-4 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5">
        {concernTiles.map((c) => (
          <Link
            key={c.title}
            to="/search"
            search={{ q: c.query }}
            className="group block"
            aria-label={`${c.title} ${c.sub}`}
          >
            <div className="squircle-tile relative aspect-square bg-[linear-gradient(180deg,var(--concern-tile-top),var(--concern-tile-bottom))] p-3 transition-transform duration-200 group-hover:-translate-y-0.5">
              <div className="flex h-full flex-col items-center justify-between">
                <img
                  src={c.image}
                  alt={`${c.title} ${c.sub}`}
                  loading="lazy"
                  width={512}
                  height={512}
                  className="hex-photo mt-1 h-[52%] w-[62%] object-cover drop-shadow-md"
                />
                <div className="pb-1 text-center leading-tight">
                  <p className="font-display text-sm font-extrabold uppercase text-white sm:text-base lg:text-lg">
                    {c.title}
                  </p>
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-white/90 sm:text-xs">
                    {c.sub}
                  </p>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
