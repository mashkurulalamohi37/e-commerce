import { useCallback, useEffect, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { Banner } from "@/lib/banners.functions";
import { BannerImage } from "./BannerImage";
import { cn } from "@/lib/utils";

/**
 * Full-bleed hero carousel: swipeable on touch, arrow buttons from md up,
 * dots on every breakpoint, one slide per view at all sizes.
 */
export function HeroCarousel({ slides }: { slides: Banner[] }) {
  const [emblaRef, embla] = useEmblaCarousel({ loop: true, align: "start", containScroll: "trimSnaps" }, [
    Autoplay({ delay: 5000, stopOnInteraction: false, stopOnMouseEnter: true }),
  ]);
  const [selected, setSelected] = useState(0);

  const onSelect = useCallback(() => {
    if (embla) setSelected(embla.selectedScrollSnap());
  }, [embla]);

  useEffect(() => {
    if (!embla) return;
    onSelect();
    embla.on("select", onSelect).on("reInit", onSelect);
  }, [embla, onSelect]);

  if (!slides.length) return null;

  return (
    <section aria-roledescription="carousel" aria-label="Featured offers" className="relative">
      <div className="overflow-hidden rounded-2xl" ref={emblaRef}>
        <div className="flex touch-pan-y">
          {slides.map((slide, i) => (
            <div
              key={slide.id}
              className="relative min-w-0 flex-[0_0_100%]"
              role="group"
              aria-roledescription="slide"
              aria-label={`${i + 1} of ${slides.length}`}
            >
              <Link to={(slide.ctaHref || "/offers") as "/offers"} className="block">
                <BannerImage
                  src={slide.imageUrl}
                  alt={slide.alt}
                  width={1600}
                  height={900}
                  priority={i === 0}
                  className="aspect-[16/10] w-full sm:aspect-[2/1] lg:aspect-[12/5]"
                />
                <div
                  className={cn(
                    "absolute inset-0 flex flex-col justify-end gap-1 p-4 sm:p-6 lg:p-10",
                    slide.tone === "light"
                      ? "bg-gradient-to-t from-background/85 via-background/40 to-transparent text-foreground"
                      : "bg-gradient-to-t from-foreground/80 via-foreground/35 to-transparent text-background",
                  )}
                >
                  {slide.kicker ? (
                    <span className="text-[11px] font-semibold tracking-[0.18em] uppercase opacity-90">
                      {slide.kicker}
                    </span>
                  ) : null}
                  <h2 className="section-title max-w-[22ch] text-xl leading-tight sm:text-2xl lg:text-4xl">
                    {slide.title}
                  </h2>
                  {slide.subtitle ? (
                    <p className="max-w-[38ch] text-xs opacity-90 sm:text-sm">{slide.subtitle}</p>
                  ) : null}
                  {slide.ctaLabel ? (
                    <span className="mt-2 inline-flex w-fit rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground">
                      {slide.ctaLabel}
                    </span>
                  ) : null}
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>

      {slides.length > 1 ? (
        <>
          <button
            type="button"
            aria-label="Previous slide"
            onClick={() => embla?.scrollPrev()}
            className="absolute top-1/2 left-3 hidden size-9 -translate-y-1/2 place-items-center rounded-full bg-background/85 text-foreground shadow-sm md:grid"
          >
            <ChevronLeft className="size-4" />
          </button>
          <button
            type="button"
            aria-label="Next slide"
            onClick={() => embla?.scrollNext()}
            className="absolute top-1/2 right-3 hidden size-9 -translate-y-1/2 place-items-center rounded-full bg-background/85 text-foreground shadow-sm md:grid"
          >
            <ChevronRight className="size-4" />
          </button>
          <div className="absolute inset-x-0 bottom-3 flex justify-center gap-1.5">
            {slides.map((slide, i) => (
              <button
                key={slide.id}
                type="button"
                aria-label={`Go to slide ${i + 1}`}
                aria-current={i === selected}
                onClick={() => embla?.scrollTo(i)}
                className={cn(
                  "h-1.5 rounded-full bg-background/70 transition-all",
                  i === selected ? "w-6 bg-background" : "w-1.5",
                )}
              />
            ))}
          </div>
        </>
      ) : null}
    </section>
  );
}
