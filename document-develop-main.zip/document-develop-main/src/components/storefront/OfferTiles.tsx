import { Link } from "@tanstack/react-router";
import type { Banner } from "@/lib/banners.functions";
import { BannerImage } from "./BannerImage";

/**
 * Wave-edged square offer tiles — the artwork is the message, so no text
 * overlay and no product content is drawn. 2 up on mobile, 4 up from sm.
 */
export function OfferTiles({ slides }: { slides: Banner[] }) {
  if (!slides.length) return null;

  return (
    <div className="grid grid-cols-2 gap-3 px-4 sm:grid-cols-4 sm:gap-4 sm:px-6 lg:gap-5">
      {slides.slice(0, 4).map((slide) => (
        <Link
          key={slide.id}
          to={(slide.ctaHref || "/offers") as "/offers"}
          className="wave-tile block transition-transform hover:-translate-y-0.5"
        >
          <BannerImage
            src={slide.imageUrl}
            alt={slide.alt || slide.title}
            width={800}
            height={800}
            className="aspect-square w-full"
          />
        </Link>
      ))}
    </div>
  );
}
