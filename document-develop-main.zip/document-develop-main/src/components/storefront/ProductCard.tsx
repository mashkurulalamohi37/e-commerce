import { Link } from "@tanstack/react-router";
import { discount, taka, brandName, type Product } from "@/lib/catalog";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { trackPromoConversion } from "@/lib/analytics";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const off = discount(product);

  return (
    <article className="group flex w-full flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card transition-shadow hover:shadow-lift">
      <Link to="/product/$slug" params={{ slug: product.slug }} className="relative block">
        <img
          src={product.image}
          alt={product.name}
          width={800}
          height={800}
          loading="lazy"
          className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {off > 0 && (
          <span className="absolute left-2 top-2 rounded-full bg-sale px-2 py-0.5 text-[11px] font-bold text-sale-foreground">
            -{off}%
          </span>
        )}
        {product.bestSeller && (
          <span className="absolute right-2 top-2 rounded-full bg-gold px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-gold-foreground">
            Best seller
          </span>
        )}
      </Link>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
          {brandName(product.brandSlug)}
        </p>
        <Link
          to="/product/$slug"
          params={{ slug: product.slug }}
          className="line-clamp-2 text-sm font-semibold leading-snug"
        >
          {product.name}
        </Link>
        <p className="text-xs text-muted-foreground">{product.size}</p>
        <div className="mt-1 flex items-baseline gap-2">
          <span className="text-base font-bold">{taka(product.price)}</span>
          {off > 0 && (
            <span className="text-xs text-muted-foreground line-through">{taka(product.listPrice)}</span>
          )}
        </div>
        {product.stock <= 6 && (
          <p className="text-[11px] font-medium text-sale">Only {product.stock} items left in stock</p>
        )}
        <Button size="sm" className="mt-2 w-full" onClick={() => {
            add(product);
            trackPromoConversion("add_to_cart", {
              product_slug: product.slug,
              product_name: product.name,
              price: product.price,
            });
          }}>
          Add to cart
        </Button>
      </div>
    </article>
  );
}
