import { BRAND_NAME, CONTACT, categories } from "@/lib/catalog";
import { TrustBand } from "./TrustBand";
import { BrandLogo } from "@/components/storefront/BrandLogo";
import { Link } from "@tanstack/react-router";
import { MapPin, Phone, Mail } from "lucide-react";
const groups = [
  {
    title: "Top Categories",
    links: categories.slice(0, 5).map((c) => ({ label: c.name, to: "/categories" as const })),
  },
  {
    title: "Quick Links",
    links: [
      { label: "Brands", to: "/brands" as const },
      { label: "Limited Time Offers", to: "/offers" as const },
      { label: "Loyalty Points", to: "/points" as const },
      { label: "Sign in", to: "/auth" as const },
    ],
  },
  {
    title: "Help",
    links: [
      { label: "Help Center", to: "/help" as const },
      { label: "Delivery & Returns", to: "/help" as const },
      { label: "Track Order", to: "/help" as const },
    ],
  },
];

export function SiteFooter() {
  return (
    <>
      <TrustBand />
      <footer className="border-t border-border bg-surface pb-24 pt-10 md:pb-10">

      <div className="mx-auto grid max-w-5xl gap-8 px-4 sm:grid-cols-2 md:grid-cols-4">
        <div>
          <BrandLogo imgClassName="h-14" />
          <p className="mt-3 max-w-xs text-sm text-muted-foreground">
            Authentic beauty and personal care, delivered across Bangladesh in a sealed, quality-checked box.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li className="flex gap-2">
              <MapPin className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>{CONTACT.address}</span>
            </li>
            <li className="flex gap-2">
              <Phone className="mt-0.5 size-4 shrink-0 text-primary" />
              <a href={`tel:${CONTACT.phone}`} className="transition-colors hover:text-primary">
                {CONTACT.phone}
              </a>
            </li>
            <li className="flex gap-2">
              <Mail className="mt-0.5 size-4 shrink-0 text-primary" />
              <a href={`mailto:${CONTACT.email}`} className="transition-colors hover:text-primary">
                {CONTACT.email}
              </a>
            </li>
          </ul>
        </div>
        {groups.map((g) => (
          <div key={g.title}>
            <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{g.title}</h3>
            <ul className="mt-3 space-y-2 text-sm">
              {g.links.map((l) => (
                <li key={l.label}>
                  <Link to={l.to} className="transition-colors hover:text-primary">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <p className="mx-auto mt-8 max-w-5xl px-4 text-xs text-muted-foreground">
        © {new Date().getFullYear()} {BRAND_NAME}. Prices in BDT. Delivery ৳79 inside Dhaka, ৳119 outside Dhaka.
      </p>
      </footer>
    </>

  );
}
