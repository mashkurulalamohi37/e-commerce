import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronDown, Menu, Search, User, ShoppingBag } from "lucide-react";
import { BRAND_NAME, categories } from "@/lib/catalog";
import { BrandLogo } from "@/components/storefront/BrandLogo";
import { useCart } from "@/lib/cart";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

/** Category groups shown in the desktop mega-menu bar. */
const MENU = categories.slice(0, 7);

export function SiteHeader() {
  const { count, setOpen } = useCart();
  const [openGroup, setOpenGroup] = useState<string | null>(null);

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-2 px-4">
        <Sheet>
          <SheetTrigger
            aria-label="Open menu"
            className="-ml-1 rounded-md p-2 text-foreground/80 transition-colors hover:bg-muted md:hidden"
          >
            <Menu className="size-5" />
          </SheetTrigger>
          <SheetContent side="left" className="w-80 overflow-y-auto">
            <SheetHeader>
              <SheetTitle className="font-display tracking-wide">Browse</SheetTitle>
            </SheetHeader>
            <nav className="flex flex-col gap-3 px-4 pb-10">
              {categories.map((c) => (
                <div key={c.slug}>
                  <Link
                    to="/categories"
                    hash={c.slug}
                    className="block rounded-md px-3 py-2 text-sm font-semibold transition-colors hover:bg-muted"
                  >
                    {c.name}
                  </Link>
                  <div className="mt-1 flex flex-wrap gap-1.5 px-3">
                    {c.children.map((child) => (
                      <Link
                        key={child}
                        to="/search"
                        search={{ q: child }}
                        className="rounded-full border border-border px-2.5 py-1 text-[11px] text-muted-foreground"
                      >
                        {child}
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </nav>
          </SheetContent>
        </Sheet>

        <Link to="/" className="flex items-center" aria-label={`${BRAND_NAME} home`}>
          <BrandLogo imgClassName="h-10 md:h-11" />
        </Link>

        <div className="ml-auto flex items-center gap-1">
          <Link
            to="/search"
            aria-label="Search"
            className="rounded-md p-2 text-foreground/80 transition-colors hover:bg-muted"
          >
            <Search className="size-5" />
          </Link>
          <Link
            to="/auth"
            search={{ mode: "signin" }}
            aria-label="Sign in"
            className="inline-flex items-center gap-1.5 rounded-md px-2 py-2 text-foreground/80 transition-colors hover:bg-muted hover:text-foreground"
          >
            <User className="size-5" />
            <span className="hidden text-sm font-semibold sm:inline">Sign in</span>
          </Link>

          <button
            onClick={() => setOpen(true)}
            aria-label={`Cart, ${count} items`}
            className="relative rounded-md p-2 text-foreground/80 transition-colors hover:bg-muted"
          >
            <ShoppingBag className="size-5" />
            {count > 0 && (
              <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                {count}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Desktop mega-menu bar */}
      <nav
        aria-label="Product categories"
        className="hidden border-t border-border/60 bg-surface md:block"
        onMouseLeave={() => setOpenGroup(null)}
      >
        <div className="mx-auto flex max-w-6xl items-stretch gap-1 px-4">
          {MENU.map((c) => (
            <div key={c.slug} className="relative" onMouseEnter={() => setOpenGroup(c.slug)}>
              <Link
                to="/categories"
                hash={c.slug}
                aria-expanded={openGroup === c.slug}
                className="flex items-center gap-1 px-3 py-2.5 text-[13px] font-semibold uppercase tracking-wide text-foreground/80 transition-colors hover:text-primary"
              >
                {c.name}
                <ChevronDown className="size-3.5 opacity-60" />
              </Link>

              {openGroup === c.slug && (
                <div className="absolute left-0 top-full z-50 w-64 rounded-b-xl border border-border border-t-0 bg-background p-4 shadow-card">
                  <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">
                    {c.name}
                  </p>
                  <ul className="space-y-1.5">
                    {c.children.map((child) => (
                      <li key={child}>
                        <Link
                          to="/search"
                          search={{ q: child }}
                          className="block text-sm text-foreground/80 transition-colors hover:text-primary"
                        >
                          {child}
                        </Link>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/categories"
                    hash={c.slug}
                    className="mt-3 inline-block text-xs font-semibold text-primary"
                  >
                    View all {c.name}
                  </Link>
                </div>
              )}
            </div>
          ))}

          <div className="ml-auto flex items-center gap-1">
            <Link
              to="/brands"
              className="px-3 py-2.5 text-[13px] font-semibold uppercase tracking-wide text-foreground/80 hover:text-primary"
            >
              Brands
            </Link>
            <Link
              to="/offers"
              className="my-1.5 rounded-full bg-primary px-3 py-1 text-[12px] font-bold uppercase tracking-wide text-primary-foreground"
            >
              Offers
            </Link>
          </div>
        </div>
      </nav>
    </header>
  );
}
