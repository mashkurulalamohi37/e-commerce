import { createMiddleware } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Every admin server function must use this middleware.
 * It validates the bearer token (requireSupabaseAuth) and then checks the
 * `admin` role server-side through the security-definer has_role function.
 * Client-side checks are for UI only — this is the authoritative gate.
 */
export const requireAdmin = createMiddleware({ type: "function" })
  .middleware([requireSupabaseAuth])
  .server(async ({ next, context }) => {
    const { data, error } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });

    if (error) throw new Error("Forbidden: unable to verify admin role");
    if (!data) throw new Error("Forbidden: admin role required");

    return next({ context: { ...context, isAdmin: true as const } });
  });
