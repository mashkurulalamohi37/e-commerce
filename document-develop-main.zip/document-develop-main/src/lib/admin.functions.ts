import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireAdmin } from "./admin-middleware";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const dayKey = (iso: string) => iso.slice(0, 10);

export type SalesPoint = { date: string; orders: number; revenue: number };
export type TopProduct = { name: string; units: number; revenue: number };

export type AdminAnalytics = {
  rangeDays: number;
  totals: {
    revenue: number;
    paidOrders: number;
    totalOrders: number;
    aov: number;
    carts: number;
    conversionRate: number;
    paymentSuccessRate: number;
  };
  salesByDay: SalesPoint[];
  topProducts: TopProduct[];
  lowStock: { name: string; stock: number }[];
};

export const getAdminAnalytics = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) =>
    z.object({ days: z.number().int().min(7).max(180).default(30) }).parse(input ?? {}),
  )
  .handler(async ({ data }): Promise<AdminAnalytics> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const since = new Date(Date.now() - data.days * 86_400_000).toISOString();

    const [ordersRes, itemsRes, cartsRes, stockRes] = await Promise.all([
      supabaseAdmin
        .from("orders")
        .select("id, total, payment_status, created_at")
        .gte("created_at", since),
      supabaseAdmin
        .from("order_items")
        .select("name, qty, unit_price, order_id, orders!inner(payment_status, created_at)")
        .gte("orders.created_at", since)
        .eq("orders.payment_status", "paid"),
      supabaseAdmin.from("carts").select("id", { count: "exact", head: true }).gte("created_at", since),
      supabaseAdmin.from("products").select("name, stock").order("stock", { ascending: true }).limit(6),
    ]);

    if (ordersRes.error) throw ordersRes.error;
    if (itemsRes.error) throw itemsRes.error;

    const orders = ordersRes.data ?? [];
    const paid = orders.filter((o) => o.payment_status === "paid");

    const byDay = new Map<string, SalesPoint>();
    for (let i = data.days - 1; i >= 0; i--) {
      const d = dayKey(new Date(Date.now() - i * 86_400_000).toISOString());
      byDay.set(d, { date: d, orders: 0, revenue: 0 });
    }
    for (const o of paid) {
      const point = byDay.get(dayKey(o.created_at));
      if (!point) continue;
      point.orders += 1;
      point.revenue += o.total ?? 0;
    }

    const productMap = new Map<string, TopProduct>();
    for (const it of (itemsRes.data ?? []) as { name: string; qty: number; unit_price: number }[]) {
      const entry = productMap.get(it.name) ?? { name: it.name, units: 0, revenue: 0 };
      entry.units += it.qty;
      entry.revenue += it.qty * it.unit_price;
      productMap.set(it.name, entry);
    }

    const revenue = paid.reduce((a, o) => a + (o.total ?? 0), 0);
    const carts = cartsRes.count ?? 0;
    // Sessions that reached the bag or checkout: saved carts plus any order attempt.
    const sessions = Math.max(carts, orders.length);

    return {
      rangeDays: data.days,
      totals: {
        revenue,
        paidOrders: paid.length,
        totalOrders: orders.length,
        aov: paid.length ? Math.round(revenue / paid.length) : 0,
        carts: sessions,
        conversionRate: sessions ? paid.length / sessions : 0,
        paymentSuccessRate: orders.length ? paid.length / orders.length : 0,
      },
      salesByDay: [...byDay.values()],
      topProducts: [...productMap.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 8),
      lowStock: stockRes.data ?? [],
    };
  });

export const listAdminProducts = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("products")
      .select("id, name, slug, price, list_price, stock, on_offer, published")
      .order("name");
    if (error) throw error;
    return data;
  });

export const updateAdminProduct = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        price: z.number().int().min(0).max(1_000_000),
        list_price: z.number().int().min(0).max(1_000_000),
        stock: z.number().int().min(0).max(1_000_000),
        on_offer: z.boolean(),
        published: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { id, ...patch } = data;
    const { error } = await supabaseAdmin.from("products").update(patch).eq("id", id);
    if (error) throw error;
    return { ok: true };
  });

export const listAdminOrders = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("orders")
      .select("id, order_number, customer_name, total, status, payment_status, payment_method, created_at")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw error;
    return data;
  });

export const setAdminOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["placed", "confirmed", "packed", "shipped", "delivered", "cancelled"]),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("orders")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

/**
 * Bootstrap: lets the very first signed-in user take the admin role, and only
 * while no admin exists. Afterwards it always refuses.
 */
export const claimFirstAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count, error } = await supabaseAdmin
      .from("user_roles")
      .select("id", { count: "exact", head: true })
      .eq("role", "admin");
    if (error) throw error;
    if ((count ?? 0) > 0) throw new Error("An admin already exists. Ask them to grant you access.");

    const { error: insertError } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: context.userId, role: "admin" });
    if (insertError) throw insertError;
    return { ok: true };
  });
