import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Banner, BannerPlacement } from "./banners.functions";

type Row = {
  id: string;
  placement: string;
  kicker: string;
  title: string;
  subtitle: string;
  cta_label: string;
  cta_href: string;
  image_url: string;
  alt: string;
  tone: string;
  active: boolean;
  sort_order: number;
  starts_at: string | null;
  ends_at: string | null;
};

const COLUMNS =
  "id, placement, kicker, title, subtitle, cta_label, cta_href, image_url, alt, tone, active, sort_order, starts_at, ends_at";

/** Client-side public banner fetch (works on static cPanel hosting). */
async function fetchPublicBanners(): Promise<Banner[]> {
  const { data, error } = await supabase
    .from("banners")
    .select(COLUMNS)
    .eq("active", true)
    .order("sort_order", { ascending: true });
  if (error) throw error;

  const now = Date.now();
  return ((data ?? []) as Row[])
    .map(
      (r): Banner => ({
        id: r.id,
        placement: r.placement === "offer" ? "offer" : "hero",
        kicker: r.kicker,
        title: r.title,
        subtitle: r.subtitle,
        ctaLabel: r.cta_label,
        ctaHref: r.cta_href,
        imageUrl: r.image_url,
        alt: r.alt,
        tone: r.tone === "light" ? "light" : "dark",
        active: r.active,
        sortOrder: r.sort_order,
        startsAt: r.starts_at,
        endsAt: r.ends_at,
      }),
    )
    .filter(
      (b) =>
        (!b.startsAt || new Date(b.startsAt).getTime() <= now) &&
        (!b.endsAt || new Date(b.endsAt).getTime() > now),
    );
}

export const bannersQueryOptions = queryOptions({
  queryKey: ["banners"],
  queryFn: () => fetchPublicBanners(),
  staleTime: 60_000,
});

export const byPlacement = (banners: Banner[] | undefined, placement: BannerPlacement) =>
  (banners ?? []).filter((b) => b.placement === placement);
