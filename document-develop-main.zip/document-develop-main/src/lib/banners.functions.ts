import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireAdmin } from "./admin-middleware";

export type BannerPlacement = "hero" | "offer";

export type Banner = {
  id: string;
  placement: BannerPlacement;
  kicker: string;
  title: string;
  subtitle: string;
  ctaLabel: string;
  ctaHref: string;
  imageUrl: string;
  alt: string;
  tone: "dark" | "light";
  active: boolean;
  sortOrder: number;
  startsAt: string | null;
  endsAt: string | null;
};

type Row = {
  id: string;
  placement: string;
  kicker: string;
  title: string;
  subtitle: string;
  cta_label: string;
  cta_href: string;
  image_url: string;
  alt: string;
  tone: string;
  active: boolean;
  sort_order: number;
  starts_at: string | null;
  ends_at: string | null;
};

const toBanner = (r: Row): Banner => ({
  id: r.id,
  placement: r.placement === "offer" ? "offer" : "hero",
  kicker: r.kicker,
  title: r.title,
  subtitle: r.subtitle,
  ctaLabel: r.cta_label,
  ctaHref: r.cta_href,
  imageUrl: r.image_url,
  alt: r.alt,
  tone: r.tone === "light" ? "light" : "dark",
  active: r.active,
  sortOrder: r.sort_order,
  startsAt: r.starts_at,
  endsAt: r.ends_at,
});

const COLUMNS =
  "id, placement, kicker, title, subtitle, cta_label, cta_href, image_url, alt, tone, active, sort_order, starts_at, ends_at";

/** Public read: live + in-schedule banners only, through the publishable (anon) key. */
export const listBanners = createServerFn({ method: "GET" }).handler(async (): Promise<Banner[]> => {
  const { createClient } = await import("@supabase/supabase-js");
  const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
  const supabasePublic = createClient(process.env.SUPABASE_URL!, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input: RequestInfo | URL, init?: RequestInit) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });

  const { data, error } = await supabasePublic
    .from("banners")
    .select(COLUMNS)
    .eq("active", true)
    .order("sort_order", { ascending: true });
  if (error) throw error;

  // RLS already enforces the schedule window; this keeps cached/SSR data honest.
  const now = Date.now();
  return ((data ?? []) as Row[])
    .map(toBanner)
    .filter(
      (b) =>
        (!b.startsAt || new Date(b.startsAt).getTime() <= now) &&
        (!b.endsAt || new Date(b.endsAt).getTime() > now),
    );
});

/** Admin read: includes inactive and scheduled slides. */
export const listAdminBanners = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .handler(async (): Promise<Banner[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("banners")
      .select(COLUMNS)
      .order("placement")
      .order("sort_order", { ascending: true });
    if (error) throw error;
    return ((data ?? []) as Row[]).map(toBanner);
  });

const isoOrNull = z
  .string()
  .trim()
  .max(40)
  .nullable()
  .optional()
  .transform((v) => (v ? new Date(v).toISOString() : null));

const bannerInput = z.object({
  placement: z.enum(["hero", "offer"]),
  kicker: z.string().max(60).default(""),
  title: z.string().min(1).max(120),
  subtitle: z.string().max(200).default(""),
  ctaLabel: z.string().max(40).default(""),
  ctaHref: z.string().max(200).default("/offers"),
  imageUrl: z.string().min(1).max(1000),
  alt: z.string().min(1, "Alt text is required for accessibility").max(200),
  tone: z.enum(["dark", "light"]).default("dark"),
  active: z.boolean().default(true),
  startsAt: isoOrNull,
  endsAt: isoOrNull,
});

const toRow = (d: z.infer<typeof bannerInput>) => ({
  placement: d.placement,
  kicker: d.kicker,
  title: d.title,
  subtitle: d.subtitle,
  cta_label: d.ctaLabel,
  cta_href: d.ctaHref,
  image_url: d.imageUrl,
  alt: d.alt,
  tone: d.tone,
  active: d.active,
  starts_at: d.startsAt,
  ends_at: d.endsAt,
});

export const createBanner = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) => bannerInput.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: last } = await supabaseAdmin
      .from("banners")
      .select("sort_order")
      .eq("placement", data.placement)
      .order("sort_order", { ascending: false })
      .limit(1)
      .maybeSingle();

    const { error } = await supabaseAdmin
      .from("banners")
      .insert({ ...toRow(data), sort_order: ((last?.sort_order as number | undefined) ?? 0) + 1 });
    if (error) throw error;
    return { ok: true };
  });

export const updateBanner = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) =>
    bannerInput.partial().extend({ id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { id, ...rest } = data;
    const patch: Partial<ReturnType<typeof toRow>> = {};
    if (rest.placement !== undefined) patch.placement = rest.placement;
    if (rest.kicker !== undefined) patch.kicker = rest.kicker;
    if (rest.title !== undefined) patch.title = rest.title;
    if (rest.subtitle !== undefined) patch.subtitle = rest.subtitle;
    if (rest.ctaLabel !== undefined) patch.cta_label = rest.ctaLabel;
    if (rest.ctaHref !== undefined) patch.cta_href = rest.ctaHref;
    if (rest.imageUrl !== undefined) patch.image_url = rest.imageUrl;
    if (rest.alt !== undefined) patch.alt = rest.alt;
    if (rest.tone !== undefined) patch.tone = rest.tone;
    if (rest.active !== undefined) patch.active = rest.active;
    if (rest.startsAt !== undefined) patch.starts_at = rest.startsAt;
    if (rest.endsAt !== undefined) patch.ends_at = rest.endsAt;

    const { error } = await supabaseAdmin.from("banners").update(patch).eq("id", id);
    if (error) throw error;
    return { ok: true };
  });

export const deleteBanner = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("banners").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

/** Swaps a slide with its neighbour inside the same placement. */
export const moveBanner = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), direction: z.enum(["up", "down"]) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: current, error: currentError } = await supabaseAdmin
      .from("banners")
      .select("id, placement, sort_order")
      .eq("id", data.id)
      .single();
    if (currentError) throw currentError;

    const up = data.direction === "up";
    const { data: neighbour, error: neighbourError } = await supabaseAdmin
      .from("banners")
      .select("id, sort_order")
      .eq("placement", current.placement)
      [up ? "lt" : "gt"]("sort_order", current.sort_order)
      .order("sort_order", { ascending: !up })
      .limit(1)
      .maybeSingle();
    if (neighbourError) throw neighbourError;
    if (!neighbour) return { ok: true, moved: false };

    const [a, b] = await Promise.all([
      supabaseAdmin.from("banners").update({ sort_order: neighbour.sort_order }).eq("id", current.id),
      supabaseAdmin.from("banners").update({ sort_order: current.sort_order }).eq("id", neighbour.id),
    ]);
    if (a.error) throw a.error;
    if (b.error) throw b.error;
    return { ok: true, moved: true };
  });

/** Persists a full drag-and-drop ordering for one placement. */
export const reorderBanners = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) =>
    z
      .object({ placement: z.enum(["hero", "offer"]), ids: z.array(z.string().uuid()).min(1).max(60) })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const results = await Promise.all(
      data.ids.map((id, i) =>
        supabaseAdmin
          .from("banners")
          .update({ sort_order: i + 1 })
          .eq("id", id)
          .eq("placement", data.placement),
      ),
    );
    const failed = results.find((r) => r.error);
    if (failed?.error) throw failed.error;
    return { ok: true };
  });

/** Admin image upload: stores the file in the private banners bucket and
 * returns a long-lived signed URL usable directly in <img src>. */
export const uploadBannerImage = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((input: unknown) =>
    z
      .object({
        fileName: z.string().min(1).max(200),
        contentType: z.string().regex(/^image\/(jpeg|png|webp|avif|gif)$/, "Only image files are allowed"),
        // base64 payload without the data-URL prefix, max ~6MB encoded
        base64: z.string().min(1).max(9_000_000),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const bytes = Buffer.from(data.base64, "base64");
    if (bytes.byteLength > 6 * 1024 * 1024) throw new Error("Image must be 6MB or smaller");

    const ext = (data.fileName.split(".").pop() ?? "jpg").toLowerCase().replace(/[^a-z0-9]/g, "");
    const path = `slides/${Date.now()}-${crypto.randomUUID()}.${ext || "jpg"}`;

    const { error } = await supabaseAdmin.storage
      .from("banners")
      .upload(path, bytes, { contentType: data.contentType, upsert: false });
    if (error) throw error;

    const TEN_YEARS = 60 * 60 * 24 * 365 * 10;
    const { data: signed, error: signError } = await supabaseAdmin.storage
      .from("banners")
      .createSignedUrl(path, TEN_YEARS);
    if (signError) throw signError;

    return { url: signed.signedUrl, path };
  });
