import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { products, type Product } from "./catalog";

type Line = { product: Product; qty: number };

type CartCtx = {
  lines: Line[];
  count: number;
  subtotal: number;
  open: boolean;
  setOpen: (o: boolean) => void;
  add: (p: Product, qty?: number) => void;
  setQty: (id: string, qty: number) => void;
  remove: (id: string) => void;
};

const Ctx = createContext<CartCtx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<Line[]>([{ product: products[0], qty: 1 }]);
  const [open, setOpen] = useState(false);

  const value = useMemo<CartCtx>(() => {
    const add = (p: Product, qty = 1) => {
      setLines((prev) => {
        const found = prev.find((l) => l.product.id === p.id);
        if (found) return prev.map((l) => (l.product.id === p.id ? { ...l, qty: l.qty + qty } : l));
        return [...prev, { product: p, qty }];
      });
      setOpen(true);
    };
    return {
      lines,
      open,
      setOpen,
      add,
      setQty: (id, qty) =>
        setLines((prev) =>
          qty <= 0 ? prev.filter((l) => l.product.id !== id) : prev.map((l) => (l.product.id === id ? { ...l, qty } : l)),
        ),
      remove: (id) => setLines((prev) => prev.filter((l) => l.product.id !== id)),
      count: lines.reduce((a, l) => a + l.qty, 0),
      subtotal: lines.reduce((a, l) => a + l.qty * l.product.price, 0),
    };
  }, [lines, open]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}
