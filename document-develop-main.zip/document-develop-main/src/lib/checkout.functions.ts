import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { getRequest } from "@tanstack/react-start/server";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

const DELIVERY = { inside_dhaka: 79, outside_dhaka: 119 } as const;

const lineSchema = z.object({ slug: z.string().min(1).max(120), qty: z.number().int().min(1).max(20) });

function publicClient() {
  const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
  return createClient<Database>(process.env.SUPABASE_URL!, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) {
          headers.delete("Authorization");
        }
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
  });
}

async function currentUserId(): Promise<string | null> {
  const token = getRequest()?.headers.get("authorization")?.replace("Bearer ", "");
  if (!token || token.split(".").length !== 3) return null;
  const { data } = await publicClient().auth.getClaims(token);
  return (data?.claims?.sub as string | undefined) ?? null;
}

export type StockLine = {
  slug: string;
  name: string;
  requested: number;
  available: number;
  ok: boolean;
  price: number;
};

/** Real-time stock lookup used by the cart/checkout screen. */
export const checkStock = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ items: z.array(lineSchema).max(50) }).parse(input))
  .handler(async ({ data }): Promise<StockLine[]> => {
    if (data.items.length === 0) return [];
    const supabase = publicClient();
    const { data: rows, error } = await supabase
      .from("products")
      .select("slug, name, stock, price, published")
      .in("slug", data.items.map((i) => i.slug));
    if (error) throw error;

    return data.items.map((item) => {
      const row = rows?.find((r) => r.slug === item.slug);
      const available = row && row.published ? row.stock : 0;
      return {
        slug: item.slug,
        name: row?.name ?? item.slug,
        requested: item.qty,
        available,
        ok: available >= item.qty,
        price: row?.price ?? 0,
      };
    });
  });

export const placeOrder = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        customerName: z.string().min(2).max(120),
        phone: z.string().min(6).max(20),
        address: z.string().min(5).max(400),
        city: z.string().min(2).max(80),
        deliveryZone: z.enum(["inside_dhaka", "outside_dhaka"]),
        paymentMethod: z.enum(["bkash", "card", "cod"]),
        items: z.array(lineSchema).min(1).max(50),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const supabase = publicClient();
    const { data: rows, error } = await supabase
      .from("products")
      .select("id, slug, name, size, price, stock, published")
      .in("slug", data.items.map((i) => i.slug));
    if (error) throw error;

    const lines = data.items.map((item) => {
      const row = rows?.find((r) => r.slug === item.slug);
      if (!row || !row.published) throw new Error(`Product unavailable: ${item.slug}`);
      return { row, qty: item.qty };
    });

    // Real-time stock validation before the order is written.
    const short = lines.filter((l) => l.row.stock < l.qty);
    if (short.length) {
      return {
        ok: false as const,
        reason: "out_of_stock" as const,
        items: short.map((l) => ({ name: l.row.name, available: l.row.stock, requested: l.qty })),
      };
    }

    const subtotal = lines.reduce((a, l) => a + l.row.price * l.qty, 0);
    const deliveryFee = DELIVERY[data.deliveryZone];
    const total = subtotal + deliveryFee;
    const userId = await currentUserId();
    const orderNumber = `NJ-${Date.now().toString(36).toUpperCase()}`;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order, error: orderError } = await supabaseAdmin
      .from("orders")
      .insert({
        order_number: orderNumber,
        user_id: userId,
        customer_name: data.customerName,
        phone: data.phone,
        address: data.address,
        city: data.city,
        delivery_zone: data.deliveryZone,
        payment_method: data.paymentMethod,
        subtotal,
        delivery_fee: deliveryFee,
        total,
      })
      .select("id, order_number")
      .single();
    if (orderError) throw orderError;

    const { error: itemsError } = await supabaseAdmin.from("order_items").insert(
      lines.map((l) => ({
        order_id: order.id,
        product_id: l.row.id,
        name: l.row.name,
        size: l.row.size ?? "",
        unit_price: l.row.price,
        qty: l.qty,
      })),
    );
    if (itemsError) throw itemsError;

    return { ok: true as const, orderId: order.id, orderNumber: order.order_number, total };
  });

/** Simulated gateway. On success, inventory is decremented atomically in Postgres. */
export const confirmPayment = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ orderId: z.string().uuid(), reference: z.string().max(60).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const reference = data.reference?.trim() || `SIM-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;

    const { error } = await supabaseAdmin.rpc("confirm_order_and_decrement_stock", {
      _order_id: data.orderId,
      _payment_reference: reference,
    });

    if (error) {
      const outOfStock = error.message?.includes("OUT_OF_STOCK");
      await supabaseAdmin
        .from("orders")
        .update({ payment_status: outOfStock ? "pending" : "failed" })
        .eq("id", data.orderId);
      return {
        ok: false as const,
        status: outOfStock ? ("out_of_stock" as const) : ("failed" as const),
        message: outOfStock
          ? `${error.message.split("OUT_OF_STOCK:")[1] ?? "An item"} just sold out — your card was not charged.`
          : "Payment could not be completed. Please try again.",
      };
    }

    return { ok: true as const, status: "paid" as const, reference };
  });

export const getOrderStatus = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ orderNumber: z.string().min(3).max(40) }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .select("order_number, status, payment_status, payment_method, total, created_at, city")
      .eq("order_number", data.orderNumber.toUpperCase())
      .maybeSingle();
    if (error) throw error;
    return order;
  });
