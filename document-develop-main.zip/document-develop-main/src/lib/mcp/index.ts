import { auth, defineMcp } from "@lovable.dev/mcp-js";
import searchProducts from "./tools/search-products";
import getProduct from "./tools/get-product";
import listOffers from "./tools/list-offers";
import listMyOrders from "./tools/list-my-orders";
import getOrder from "./tools/get-order";

// The OAuth issuer must be the direct Supabase host; the project ref is the only
// value that survives publish unchanged and is inlined by Vite at build time.
const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_ID ?? "project-ref-unset";

export default defineMcp({
  name: "noorja-mcp",
  title: "Noorja Beauty",
  version: "0.1.0",
  instructions:
    "Tools for the Noorja beauty storefront. Use `search_products` and `get_product` to browse the catalog, `list_offers` for live promotions, and `list_my_orders` / `get_order` for the signed-in customer's order history and delivery status.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [searchProducts, getProduct, listOffers, listMyOrders, getOrder],
});
