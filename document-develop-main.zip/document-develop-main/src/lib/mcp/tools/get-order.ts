import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { errorResult, supabaseForUser, textResult } from "../supabase";

export default defineTool({
  name: "get_order",
  title: "Get order details",
  description: "Fetch one of the signed-in customer's orders, including its line items, by order number.",
  inputSchema: { orderNumber: z.string().describe("Order number shown at checkout, e.g. 'NRJ-10023'.") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ orderNumber }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const supabase = supabaseForUser(ctx);
    const { data: order, error } = await supabase
      .from("orders")
      .select("*")
      .eq("order_number", orderNumber)
      .eq("user_id", ctx.getUserId()!)
      .maybeSingle();
    if (error) return errorResult(error.message);
    if (!order) return errorResult(`No order "${orderNumber}" found on your account.`);
    const { data: items, error: itemsError } = await supabase
      .from("order_items")
      .select("name,size,qty,unit_price")
      .eq("order_id", order.id);
    if (itemsError) return errorResult(itemsError.message);
    const result = { order, items: items ?? [] };
    return { ...textResult(result), structuredContent: result };
  },
});
