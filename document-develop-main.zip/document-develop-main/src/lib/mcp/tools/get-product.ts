import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { errorResult, supabaseForUser, textResult } from "../supabase";

export default defineTool({
  name: "get_product",
  title: "Get product details",
  description: "Fetch full details and live stock for one product by its slug.",
  inputSchema: { slug: z.string().describe("Product slug, e.g. 'glow-serum-30ml'.") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ slug }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const { data, error } = await supabaseForUser(ctx)
      .from("products")
      .select("*")
      .eq("slug", slug)
      .eq("published", true)
      .maybeSingle();
    if (error) return errorResult(error.message);
    if (!data) return errorResult(`No published product found with slug "${slug}".`);
    return { ...textResult(data), structuredContent: { product: data } };
  },
});
