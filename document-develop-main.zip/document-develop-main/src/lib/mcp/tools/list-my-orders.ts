import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { errorResult, supabaseForUser, textResult } from "../supabase";

export default defineTool({
  name: "list_my_orders",
  title: "List my orders",
  description: "List the signed-in customer's Noorja orders with status, payment status and totals.",
  inputSchema: { limit: z.number().optional().describe("Max orders to return (default 10, max 50).") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ limit }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const take = Math.min(Math.max(limit ?? 10, 1), 50);
    const { data, error } = await supabaseForUser(ctx)
      .from("orders")
      .select("id,order_number,status,payment_status,payment_method,total,subtotal,delivery_fee,city,created_at")
      .eq("user_id", ctx.getUserId()!)
      .order("created_at", { ascending: false })
      .limit(take);
    if (error) return errorResult(error.message);
    return { ...textResult(data ?? []), structuredContent: { orders: data ?? [] } };
  },
});
