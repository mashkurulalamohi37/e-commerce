import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { errorResult, supabaseForUser, textResult } from "../supabase";

export default defineTool({
  name: "list_offers",
  title: "List live offers",
  description: "List currently discounted products and the live promotional banners on the storefront.",
  inputSchema: { limit: z.number().optional().describe("Max discounted products to return (default 12, max 50).") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ limit }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const take = Math.min(Math.max(limit ?? 12, 1), 50);
    const supabase = supabaseForUser(ctx);
    const { data: products, error } = await supabase
      .from("products")
      .select("slug,name,brand_slug,price,list_price,offer_ends_at,stock")
      .eq("published", true)
      .eq("on_offer", true)
      .limit(take);
    if (error) return errorResult(error.message);
    const { data: banners } = await supabase
      .from("banners")
      .select("title,subtitle,placement,cta_href,starts_at,ends_at")
      .eq("active", true)
      .order("sort_order");
    const result = { products: products ?? [], banners: banners ?? [] };
    return { ...textResult(result), structuredContent: result };
  },
});
