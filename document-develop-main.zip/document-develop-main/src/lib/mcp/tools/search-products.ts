import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { errorResult, supabaseForUser, textResult } from "../supabase";

export default defineTool({
  name: "search_products",
  title: "Search products",
  description: "Search the Noorja beauty catalog by name, brand, category or offer status.",
  inputSchema: {
    query: z.string().optional().describe("Free-text match against product name."),
    brandSlug: z.string().optional().describe("Filter by brand slug, e.g. 'noorja-labs'."),
    category: z.string().optional().describe("Filter by category slug."),
    onOfferOnly: z.boolean().optional().describe("Only return products currently on offer."),
    limit: z.number().optional().describe("Max rows to return (default 20, max 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ query, brandSlug, category, onOfferOnly, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const take = Math.min(Math.max(limit ?? 20, 1), 50);
    let q = supabaseForUser(ctx)
      .from("products")
      .select("id,slug,name,brand_slug,price,list_price,on_offer,stock,rating,categories,size,brief")
      .eq("published", true)
      .limit(take);
    if (query) q = q.ilike("name", `%${query}%`);
    if (brandSlug) q = q.eq("brand_slug", brandSlug);
    if (category) q = q.contains("categories", [category]);
    if (onOfferOnly) q = q.eq("on_offer", true);
    const { data, error } = await q;
    if (error) return errorResult(error.message);
    return { ...textResult(data ?? []), structuredContent: { products: data ?? [] } };
  },
});
