import { queryOptions } from "@tanstack/react-query";
import { brandName, products, type Product } from "@/lib/catalog";

/** Async so the UI has a real loading state (and a single place to swap in an API later). */
export async function searchProducts(term: string): Promise<Product[]> {
  const q = term.trim().toLowerCase();
  await new Promise((r) => setTimeout(r, q ? 260 : 120));
  if (!q) return products;
  return products.filter((p) =>
    [p.name, brandName(p.brandSlug), ...p.categories, ...p.concerns]
      .join(" ")
      .toLowerCase()
      .includes(q),
  );
}

export const searchQueryOptions = (term: string) =>
  queryOptions({
    queryKey: ["search", term.trim().toLowerCase()],
    queryFn: () => searchProducts(term),
    staleTime: 30_000,
  });
