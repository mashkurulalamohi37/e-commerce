import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { toast } from "sonner";
import {
  getAdminAnalytics,
  listAdminOrders,
  listAdminProducts,
  setAdminOrderStatus,
  updateAdminProduct,
} from "@/lib/admin.functions";
import { BannersPanel } from "@/components/admin/BannersPanel";
import { useAuth } from "@/lib/auth";

import { taka } from "@/lib/catalog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — Nills Mart Store Analytics" },
      { name: "description", content: "Sales analytics, inventory and order management for the Nills Mart store team." },
      { property: "og:title", content: "Admin Dashboard — Nills Mart" },
      { property: "og:description", content: "Sales by day, top products, conversion and payment success rates." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const pct = (n: number) => `${(n * 100).toFixed(1)}%`;

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-card">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl font-semibold">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function AdminPage() {
  const { isAdmin, loading, user } = useAuth();

  if (loading) {
    return <p className="px-4 py-10 text-center text-sm text-muted-foreground">Checking access…</p>;
  }

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <h1 className="font-display text-2xl font-semibold">Admin access required</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {user?.email} does not have the admin role. Ask an existing admin to grant access.
        </p>
        <Button asChild className="mt-6">
          <Link to="/">Back to store</Link>
        </Button>
      </div>
    );
  }

  return <AdminDashboard />;
}

function AdminDashboard() {
  const analyticsFn = useServerFn(getAdminAnalytics);
  const productsFn = useServerFn(listAdminProducts);
  const ordersFn = useServerFn(listAdminOrders);

  const analytics = useQuery({
    queryKey: ["admin", "analytics", 30],
    queryFn: () => analyticsFn({ data: { days: 30 } }),
  });
  const products = useQuery({ queryKey: ["admin", "products"], queryFn: () => productsFn({}) });
  const orders = useQuery({ queryKey: ["admin", "orders"], queryFn: () => ordersFn({}) });

  const a = analytics.data;

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="font-display text-2xl font-semibold">Admin dashboard</h1>
      <p className="mt-1 text-sm text-muted-foreground">Last 30 days · live store data</p>

      <Tabs defaultValue="analytics" className="mt-5">
        <TabsList>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="banners">Banners</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
        </TabsList>

        <TabsContent value="banners">
          <BannersPanel />
        </TabsContent>


        <TabsContent value="analytics" className="space-y-5">
          {analytics.isLoading && <p className="text-sm text-muted-foreground">Loading analytics…</p>}
          {analytics.isError && (
            <p className="text-sm text-destructive">Could not load analytics: {(analytics.error as Error).message}</p>
          )}
          {a && (
            <>
              <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                <Stat label="Revenue" value={taka(a.totals.revenue)} hint={`${a.totals.paidOrders} paid orders`} />
                <Stat label="Avg order value" value={taka(a.totals.aov)} />
                <Stat
                  label="Conversion rate"
                  value={pct(a.totals.conversionRate)}
                  hint={`${a.totals.paidOrders} of ${a.totals.carts} sessions`}
                />
                <Stat
                  label="Payment success"
                  value={pct(a.totals.paymentSuccessRate)}
                  hint={`${a.totals.paidOrders} of ${a.totals.totalOrders} attempts`}
                />
              </div>

              <div className="rounded-xl border border-border bg-card p-4 shadow-card">
                <h2 className="section-title">Sales by day</h2>
                <div className="mt-3 h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={a.salesByDay}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" vertical={false} />
                      <XAxis dataKey="date" tickFormatter={(d: string) => d.slice(5)} fontSize={11} />
                      <YAxis fontSize={11} width={48} />
                      <Tooltip formatter={(v: number) => taka(Number(v))} />
                      <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-xl border border-border bg-card p-4 shadow-card">
                  <h2 className="section-title">Top products</h2>
                  <ul className="mt-3 space-y-2 text-sm">
                    {a.topProducts.length === 0 && <li className="text-muted-foreground">No paid orders yet.</li>}
                    {a.topProducts.map((p) => (
                      <li key={p.name} className="flex justify-between gap-3">
                        <span className="truncate">{p.name}</span>
                        <span className="shrink-0 font-semibold">
                          {p.units} · {taka(p.revenue)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-xl border border-border bg-card p-4 shadow-card">
                  <h2 className="section-title">Lowest stock</h2>
                  <ul className="mt-3 space-y-2 text-sm">
                    {a.lowStock.map((p) => (
                      <li key={p.name} className="flex justify-between gap-3">
                        <span className="truncate">{p.name}</span>
                        <span className={p.stock <= 5 ? "font-semibold text-sale" : "font-semibold"}>{p.stock}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="products">
          {products.isLoading && <p className="text-sm text-muted-foreground">Loading products…</p>}
          <div className="space-y-3">
            {products.data?.map((p) => <ProductRow key={p.id} product={p} />)}
          </div>
        </TabsContent>

        <TabsContent value="orders">
          {orders.isLoading && <p className="text-sm text-muted-foreground">Loading orders…</p>}
          <div className="space-y-2">
            {orders.data?.map((o) => <OrderRow key={o.id} order={o} />)}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

type ProductRowData = {
  id: string;
  name: string;
  price: number;
  list_price: number;
  stock: number;
  on_offer: boolean;
  published: boolean;
};

function ProductRow({ product }: { product: ProductRowData }) {
  const qc = useQueryClient();
  const save = useServerFn(updateAdminProduct);
  const [draft, setDraft] = useState(product);

  const mutation = useMutation({
    mutationFn: () =>
      save({
        data: {
          id: draft.id,
          price: Number(draft.price),
          list_price: Number(draft.list_price),
          stock: Number(draft.stock),
          on_offer: draft.on_offer,
          published: draft.published,
        },
      }),
    onSuccess: () => {
      toast.success(`${draft.name} updated`);
      qc.invalidateQueries({ queryKey: ["admin"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="rounded-xl border border-border bg-card p-3 shadow-card">
      <p className="text-sm font-semibold">{product.name}</p>
      <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <label className="text-xs text-muted-foreground">
          Price
          <Input
            type="number"
            value={draft.price}
            onChange={(e) => setDraft({ ...draft, price: Number(e.target.value) })}
          />
        </label>
        <label className="text-xs text-muted-foreground">
          List price
          <Input
            type="number"
            value={draft.list_price}
            onChange={(e) => setDraft({ ...draft, list_price: Number(e.target.value) })}
          />
        </label>
        <label className="text-xs text-muted-foreground">
          Stock
          <Input
            type="number"
            value={draft.stock}
            onChange={(e) => setDraft({ ...draft, stock: Number(e.target.value) })}
          />
        </label>
        <div className="flex items-end gap-3 pb-1">
          <label className="flex items-center gap-2 text-xs">
            <Switch checked={draft.on_offer} onCheckedChange={(v) => setDraft({ ...draft, on_offer: v })} />
            Offer
          </label>
          <label className="flex items-center gap-2 text-xs">
            <Switch checked={draft.published} onCheckedChange={(v) => setDraft({ ...draft, published: v })} />
            Live
          </label>
        </div>
      </div>
      <Button size="sm" className="mt-3" onClick={() => mutation.mutate()} disabled={mutation.isPending}>
        Save
      </Button>
    </div>
  );
}

const STATUSES = ["placed", "confirmed", "packed", "shipped", "delivered", "cancelled"] as const;

function OrderRow({
  order,
}: {
  order: {
    id: string;
    order_number: string;
    customer_name: string;
    total: number;
    status: string;
    payment_status: string;
    created_at: string;
  };
}) {
  const qc = useQueryClient();
  const setStatus = useServerFn(setAdminOrderStatus);
  const mutation = useMutation({
    mutationFn: (status: (typeof STATUSES)[number]) => setStatus({ data: { id: order.id, status } }),
    onSuccess: () => {
      toast.success("Order updated");
      qc.invalidateQueries({ queryKey: ["admin", "orders"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-card p-3 text-sm shadow-card">
      <div>
        <p className="font-semibold">{order.order_number}</p>
        <p className="text-xs text-muted-foreground">
          {order.customer_name} · {taka(order.total)} · {order.payment_status}
        </p>
      </div>
      <select
        className="rounded-md border border-input bg-background px-2 py-1 text-xs"
        value={order.status}
        disabled={mutation.isPending}
        onChange={(e) => mutation.mutate(e.target.value as (typeof STATUSES)[number])}
      >
        {STATUSES.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>
    </div>
  );
}
