import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Eye, EyeOff, Lock, Mail, ShoppingBag, UserRound } from "lucide-react";
import { toast } from "sonner";

import { claimFirstAdmin } from "@/lib/admin.functions";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { BRAND_NAME } from "@/lib/catalog";
import { BrandLogo } from "@/components/storefront/BrandLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

function safeNext(next: string | undefined) {
  return next && next.startsWith("/") && !next.startsWith("//") ? next : null;
}

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { next?: string; mode?: string } => ({
    ...(typeof s.next === "string" ? { next: s.next } : {}),
    ...(s.mode === "signup" || s.mode === "signin" ? { mode: s.mode } : {}),
  }),
  head: () => ({
    meta: [
      { title: `Sign in or create an account — ${BRAND_NAME}` },
      {
        name: "description",
        content: `Sign in or create a ${BRAND_NAME} account to track orders, save your bag and checkout faster.`,
      },
      { property: "og:title", content: `Account — ${BRAND_NAME}` },
      {
        property: "og:description",
        content: "Access your orders, saved bag and account tools.",
      },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const redirectTo = safeNext(search.next);
  const { user, signOut, isAdmin } = useAuth();
  const claimAdmin = useServerFn(claimFirstAdmin);

  const [mode, setMode] = useState<"signin" | "signup">(
    search.mode === "signup" ? "signup" : "signin",
  );
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);

  if (user && redirectTo) {
    window.location.href = redirectTo;
    return null;
  }

  if (user) {
    return (
      <AuthShell>
        <div className="text-center">
          <div className="mx-auto mb-4 grid size-14 place-items-center rounded-full bg-primary/15 text-primary">
            <UserRound className="size-7" />
          </div>
          <h1 className="font-display text-2xl font-semibold tracking-tight">You're signed in</h1>
          <p className="mt-1 text-sm text-muted-foreground">{user.email}</p>
        </div>
        <div className="mt-8 space-y-2">
          {isAdmin ? (
            <Button className="w-full" size="lg" onClick={() => navigate({ to: "/admin" })}>
              Open admin dashboard
            </Button>
          ) : (
            <Button
              variant="secondary"
              className="w-full"
              size="lg"
              onClick={async () => {
                try {
                  await claimAdmin({});
                  toast.success("Admin access granted. Reloading…");
                  window.location.reload();
                } catch (err) {
                  toast.error((err as Error).message);
                }
              }}
            >
              Claim admin access
            </Button>
          )}
          <Button className="w-full" size="lg" variant="outline" onClick={() => navigate({ to: "/" })}>
            Continue shopping
          </Button>
          <Button variant="ghost" className="w-full" onClick={signOut}>
            Sign out
          </Button>
        </div>
      </AuthShell>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === "signup") {
      if (password !== confirm) {
        toast.error("Passwords do not match.");
        return;
      }
      if (password.length < 6) {
        toast.error("Password must be at least 6 characters.");
        return;
      }
    }

    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: { full_name: name.trim() || undefined },
            emailRedirectTo: `${window.location.origin}${import.meta.env.BASE_URL}auth`,
          },
        });
        if (error) throw error;
        toast.success("Account created. Check your inbox to confirm your email, then sign in.");
        setMode("signin");
        setPassword("");
        setConfirm("");
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (error) throw error;
        toast.success("Welcome back!");
        if (redirectTo) {
          window.location.href = redirectTo;
        } else {
          navigate({ to: "/" });
        }
      }
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell>
      <div className="text-center">
        <h1 className="font-display text-2xl font-semibold tracking-tight sm:text-3xl">
          {mode === "signin" ? "Welcome back" : "Create your account"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {mode === "signin"
            ? `Sign in to track orders and checkout faster at ${BRAND_NAME}.`
            : `Join ${BRAND_NAME} for deals, order tracking and a faster checkout.`}
        </p>
      </div>

      <div
        role="tablist"
        aria-label="Account mode"
        className="mt-6 grid grid-cols-2 rounded-full bg-muted p-1"
      >
        <button
          type="button"
          role="tab"
          aria-selected={mode === "signin"}
          className={cn(
            "rounded-full px-3 py-2 text-sm font-semibold transition-colors",
            mode === "signin"
              ? "bg-background text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground",
          )}
          onClick={() => setMode("signin")}
        >
          Sign in
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={mode === "signup"}
          className={cn(
            "rounded-full px-3 py-2 text-sm font-semibold transition-colors",
            mode === "signup"
              ? "bg-background text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground",
          )}
          onClick={() => setMode("signup")}
        >
          Sign up
        </button>
      </div>

      <form className="mt-6 space-y-4" onSubmit={submit}>
        {mode === "signup" && (
          <div className="space-y-2">
            <Label htmlFor="auth-name">Full name</Label>
            <div className="relative">
              <UserRound className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="auth-name"
                autoComplete="name"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-11 pl-10"
              />
            </div>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="auth-email">Email</Label>
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="auth-email"
              type="email"
              required
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-11 pl-10"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="auth-password">Password</Label>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="auth-password"
              type={showPassword ? "text" : "password"}
              required
              minLength={6}
              autoComplete={mode === "signin" ? "current-password" : "new-password"}
              placeholder={mode === "signup" ? "At least 6 characters" : "Your password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-11 pl-10 pr-10"
            />
            <button
              type="button"
              aria-label={showPassword ? "Hide password" : "Show password"}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
              onClick={() => setShowPassword((v) => !v)}
            >
              {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>

        {mode === "signup" && (
          <div className="space-y-2">
            <Label htmlFor="auth-confirm">Confirm password</Label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="auth-confirm"
                type={showPassword ? "text" : "password"}
                required
                minLength={6}
                autoComplete="new-password"
                placeholder="Repeat password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="h-11 pl-10"
              />
            </div>
          </div>
        )}

        <Button type="submit" size="lg" className="h-11 w-full text-base" disabled={busy}>
          {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
        </Button>
      </form>

      <p className="mt-5 text-center text-sm text-muted-foreground">
        {mode === "signin" ? (
          <>
            New to {BRAND_NAME}?{" "}
            <button
              type="button"
              className="font-semibold text-primary underline-offset-4 hover:underline"
              onClick={() => setMode("signup")}
            >
              Create an account
            </button>
          </>
        ) : (
          <>
            Already have an account?{" "}
            <button
              type="button"
              className="font-semibold text-primary underline-offset-4 hover:underline"
              onClick={() => setMode("signin")}
            >
              Sign in
            </button>
          </>
        )}
      </p>

      <div className="mt-6 flex items-start gap-2 rounded-xl bg-secondary/70 px-3 py-3 text-xs text-muted-foreground">
        <ShoppingBag className="mt-0.5 size-4 shrink-0 text-primary" />
        <p>
          After signing in you can track orders, save your bag across devices, and check out more quickly.
        </p>
      </div>

      <p className="mt-4 text-center text-xs text-muted-foreground">
        <Link to="/" className="underline-offset-4 hover:underline">
          Back to shopping
        </Link>
      </p>
    </AuthShell>
  );
}

function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative min-h-[70vh] overflow-hidden px-4 py-10 sm:py-14">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,_oklch(0.92_0.04_195),_transparent_55%),radial-gradient(ellipse_at_bottom_right,_oklch(0.93_0.03_270),_transparent_50%)]"
      />
      <div className="relative mx-auto w-full max-w-md">
        <div className="mb-6 flex justify-center">
          <BrandLogo imgClassName="h-16 sm:h-20" />
        </div>
        <div className="rounded-2xl border border-border/80 bg-background/90 p-6 shadow-[0_12px_40px_oklch(0.32_0.07_270/0.08)] backdrop-blur sm:p-8">
          {children}
        </div>
      </div>
    </div>
  );
}
