import { createFileRoute, Link } from "@tanstack/react-router";
import { brands, products } from "@/lib/catalog";

export const Route = createFileRoute("/brands")({
  head: () => ({
    meta: [
      { title: "All Beauty Brands — Nills Mart Bangladesh" },
      {
        name: "description",
        content: "Browse top brands and all brands of authentic skincare, makeup and hair care available in Bangladesh.",
      },
      { property: "og:title", content: "All Beauty Brands — Nills Mart" },
      { property: "og:description", content: "Top brands and all brands, 100% genuine, delivered nationwide." },
    ],
  }),
  component: Brands,
});

function BrandCard({ slug, name, origin }: { slug: string; name: string; origin: string }) {
  const count = products.filter((p) => p.brandSlug === slug).length;
  return (
    <Link
      to="/search"
      search={{ q: name }}
      className="rounded-xl border border-border bg-card p-4 shadow-card transition-shadow hover:shadow-lift"
    >
      <p className="font-display text-base font-semibold">{name}</p>
      <p className="mt-1 text-xs text-muted-foreground">
        {origin} · {count} products
      </p>
    </Link>
  );
}

function Brands() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="font-display text-2xl font-semibold">Brands</h1>

      <h2 className="section-title mt-6">Top Brands</h2>
      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {brands.filter((b) => b.top).map((b) => (
          <BrandCard key={b.slug} {...b} />
        ))}
      </div>

      <h2 className="section-title mt-8">All Brands</h2>
      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {brands.map((b) => (
          <BrandCard key={b.slug} {...b} />
        ))}
      </div>
    </div>
  );
}
