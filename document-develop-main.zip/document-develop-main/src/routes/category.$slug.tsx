import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ProductCard } from "@/components/storefront/ProductCard";
import { categoryBySlug, productsInCategory } from "@/lib/catalog";

export const Route = createFileRoute("/category/$slug")({
  loader: ({ params }) => {
    const category = categoryBySlug(params.slug);
    if (!category) throw notFound();
    return { category };
  },
  head: ({ loaderData }) => {
    const name = loaderData?.category.name ?? "Category";
    const description = `Shop ${name.toLowerCase()} products at Nills Mart — 100% genuine beauty and personal care delivered across Bangladesh.`;
    return {
      meta: [
        { title: `${name} — Shop ${name} Online | Nills Mart` },
        { name: "description", content: description },
        { property: "og:title", content: `${name} — Nills Mart Bangladesh` },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const { category } = Route.useLoaderData();
  const items = productsInCategory(slug);

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <nav className="text-xs text-muted-foreground">
        <Link to="/" className="hover:text-primary">
          Home
        </Link>
        <span className="px-1">/</span>
        <Link to="/categories" className="hover:text-primary">
          Categories
        </Link>
      </nav>
      <h1 className="mt-2 font-display text-2xl font-semibold">{category.name}</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {items.length} {items.length === 1 ? "product" : "products"}
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {category.children.map((child: string) => (
          <Link
            key={child}
            to="/search"
            search={{ q: child }}
            className="rounded-full bg-muted px-3 py-1.5 text-xs font-medium transition-colors hover:bg-accent"
          >
            {child}
          </Link>
        ))}
      </div>

      {items.length ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      ) : (
        <p className="mt-8 text-sm text-muted-foreground">
          No products in this category yet. Check back soon.
        </p>
      )}
    </div>
  );
}
