import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { useCart } from "@/lib/cart";
import { checkStock, confirmPayment, placeOrder } from "@/lib/checkout.functions";
import { taka, DELIVERY_INSIDE_DHAKA, DELIVERY_OUTSIDE_DHAKA } from "@/lib/catalog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trackPromoConversion } from "@/lib/analytics";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Secure Checkout — Pay with bKash or Card | Nills Mart" },
      {
        name: "description",
        content: "Complete your Nills Mart order with bKash, card or cash on delivery. Live stock checks before payment.",
      },
      { property: "og:title", content: "Secure Checkout — Nills Mart" },
      { property: "og:description", content: "bKash, card and cash on delivery with live stock validation." },
    ],
  }),
  component: Checkout,
});

type Zone = "inside_dhaka" | "outside_dhaka";
type Method = "bkash" | "card" | "cod";

function Checkout() {
  const navigate = useNavigate();
  const { lines, subtotal } = useCart();
  const checkStockFn = useServerFn(checkStock);
  const placeOrderFn = useServerFn(placeOrder);
  const confirmPaymentFn = useServerFn(confirmPayment);

  const [form, setForm] = useState({ customerName: "", phone: "", address: "", city: "Dhaka" });
  const [zone, setZone] = useState<Zone>("inside_dhaka");
  const [method, setMethod] = useState<Method>("bkash");
  const [busy, setBusy] = useState(false);

  const items = lines.map((l) => ({ slug: l.product.slug, qty: l.qty }));

  const stock = useQuery({
    queryKey: ["stock", items],
    enabled: items.length > 0,
    refetchInterval: 20_000,
    queryFn: () => checkStockFn({ data: { items } }),
  });

  const blocked = (stock.data ?? []).filter((l) => !l.ok);
  const deliveryFee = zone === "inside_dhaka" ? DELIVERY_INSIDE_DHAKA : DELIVERY_OUTSIDE_DHAKA;

  useEffect(() => {
    if (blocked.length) toast.warning("Some items just changed availability.");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [blocked.length]);

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <h1 className="font-display text-2xl font-semibold">Your bag is empty</h1>
        <Button asChild className="mt-6">
          <Link to="/offers">Shop the offers</Link>
        </Button>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const fresh = await checkStockFn({ data: { items } });
      const short = fresh.filter((l) => !l.ok);
      if (short.length) {
        toast.error(`${short[0].name} only has ${short[0].available} left.`);
        stock.refetch();
        return;
      }

      trackPromoConversion("checkout_started");
      const order = await placeOrderFn({
        data: { ...form, deliveryZone: zone, paymentMethod: method, items },
      });

      if (!order.ok) {
        toast.error(`${order.items[0].name} only has ${order.items[0].available} left.`);
        stock.refetch();
        return;
      }

      const payment = await confirmPaymentFn({ data: { orderId: order.orderId } });
      if (!payment.ok) {
        toast.error(payment.message);
        stock.refetch();
        navigate({ to: "/track", search: { order: order.orderNumber } });
        return;
      }

      trackPromoConversion("order_placed", { order_total: order.total, order_number: order.orderNumber });
      toast.success(`Paid ${taka(order.total)} — order ${order.orderNumber}`);
      navigate({ to: "/track", search: { order: order.orderNumber } });
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <h1 className="font-display text-2xl font-semibold">Checkout</h1>

      <div className="mt-4 space-y-2 rounded-xl border border-border bg-card p-4">
        {lines.map(({ product, qty }) => {
          const live = stock.data?.find((s) => s.slug === product.slug);
          return (
            <div key={product.id} className="flex justify-between gap-3 text-sm">
              <span className="min-w-0 truncate">
                {product.name} × {qty}
                {live && !live.ok && (
                  <span className="ml-2 font-medium text-destructive">only {live.available} left</span>
                )}
                {live && live.ok && live.available <= 5 && (
                  <span className="ml-2 text-xs text-sale">{live.available} in stock</span>
                )}
              </span>
              <span className="shrink-0 font-semibold">{taka(product.price * qty)}</span>
            </div>
          );
        })}
        <div className="flex justify-between border-t border-border pt-2 text-sm">
          <span className="text-muted-foreground">Delivery</span>
          <span className="font-semibold">{taka(deliveryFee)}</span>
        </div>
        <div className="flex justify-between text-base font-bold">
          <span>Total</span>
          <span>{taka(subtotal + deliveryFee)}</span>
        </div>
      </div>

      <form className="mt-5 space-y-3" onSubmit={submit}>
        <Input
          required
          placeholder="Full name"
          value={form.customerName}
          onChange={(e) => setForm({ ...form, customerName: e.target.value })}
        />
        <Input
          required
          inputMode="tel"
          placeholder="Mobile number"
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
        />
        <Textarea
          required
          placeholder="Delivery address"
          value={form.address}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
        />
        <Input
          required
          placeholder="City"
          value={form.city}
          onChange={(e) => setForm({ ...form, city: e.target.value })}
        />

        <div className="grid grid-cols-2 gap-2">
          {(
            [
              ["inside_dhaka", `Inside Dhaka · ${taka(DELIVERY_INSIDE_DHAKA)}`],
              ["outside_dhaka", `Outside Dhaka · ${taka(DELIVERY_OUTSIDE_DHAKA)}`],
            ] as const
          ).map(([value, label]) => (
            <button
              type="button"
              key={value}
              onClick={() => setZone(value)}
              className={`rounded-lg border px-3 py-2 text-xs font-semibold ${
                zone === value ? "border-primary bg-accent" : "border-border bg-card"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-2">
          {(
            [
              ["bkash", "bKash"],
              ["card", "Card"],
              ["cod", "Cash on delivery"],
            ] as const
          ).map(([value, label]) => (
            <button
              type="button"
              key={value}
              onClick={() => setMethod(value)}
              className={`rounded-lg border px-3 py-2 text-xs font-semibold ${
                method === value ? "border-primary bg-accent" : "border-border bg-card"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <Button type="submit" size="lg" className="w-full" disabled={busy || blocked.length > 0}>
          {busy ? "Processing…" : `Pay ${taka(subtotal + deliveryFee)}`}
        </Button>
        <p className="text-center text-[11px] text-muted-foreground">
          Stock is re-checked at the moment of payment; inventory is reserved only once payment succeeds.
        </p>
      </form>
    </div>
  );
}
