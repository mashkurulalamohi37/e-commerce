import { createFileRoute } from "@tanstack/react-router";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const faqs = [
  {
    q: "How much is delivery and how long does it take?",
    a: "Delivery is ৳79 inside Dhaka and ৳119 outside Dhaka via third-party couriers. Orders inside Dhaka arrive in 1–2 days and outside Dhaka in 3–5 days.",
  },
  {
    q: "How can I pay?",
    a: "You can pay with bKash or any major debit/credit card. All payments are processed over an encrypted, secure connection.",
  },
  {
    q: "What is your return policy?",
    a: "Damaged, defective or wrong items can be reported within 3 days of delivery. Electronics have a 15-day replacement window. Used, liquid, semi-liquid and clearance items are not returnable.",
  },
  {
    q: "Are the products genuine?",
    a: "Yes. Every item is sourced from authorised channels, quality-inspected and shipped in a closed box.",
  },
  {
    q: "How do loyalty points work?",
    a: "You earn 1 point for every ৳100 on successfully completed orders. Online points can take up to 21 days to post; showroom points post within 24 hours. Points can be redeemed for vouchers, including free-delivery vouchers.",
  },
];

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Help Center — Delivery, Returns & Payments | Nills Mart" },
      { name: "description", content: "Delivery charges, return rules, payment options and order support for Nills Mart customers in Bangladesh." },
      { property: "og:title", content: "Help Center — Nills Mart" },
      { property: "og:description", content: "Answers on delivery, returns, payments and loyalty points." },
    ],
  }),
  component: Help,
});

function Help() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <h1 className="font-display text-2xl font-semibold">Help Center</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Chat with a beauty advisor 10am–8pm, or read the most common questions below.
      </p>
      <Accordion type="single" collapsible className="mt-4">
        {faqs.map((f) => (
          <AccordionItem key={f.q} value={f.q}>
            <AccordionTrigger className="text-left text-sm">{f.q}</AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
