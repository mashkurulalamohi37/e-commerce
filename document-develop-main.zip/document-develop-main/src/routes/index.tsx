import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ShieldCheck, Truck, Lock, Headphones } from "lucide-react";
import { ProductCard } from "@/components/storefront/ProductCard";
import { HeroCarousel } from "@/components/storefront/HeroCarousel";
import { OfferTiles } from "@/components/storefront/OfferTiles";
import { bannersQueryOptions, byPlacement } from "@/lib/banner-queries";
import { categoryBySlug, categoryCount, products } from "@/lib/catalog";
import { ConcernTiles } from "@/components/storefront/ConcernTiles";
import { BrandOfferGrid } from "@/components/storefront/BrandOfferGrid";
import catMakeup from "@/assets/cat-makeup.jpg";
import catKbeauty from "@/assets/cat-kbeauty.jpg";
import catHair from "@/assets/cat-hair.jpg";
import catBaby from "@/assets/cat-baby.jpg";

const categoryTiles = [
  {
    slug: "makeup",
    image: catMakeup,
    alt: "Shop makeup category",
    blurb: "Lips, face, eyes and nails from colour-first labels.",
  },
  {
    slug: "skin-care",
    image: catKbeauty,
    alt: "Shop K-beauty skin care category",
    blurb: "Cleansers, serums and moisturizers for humid weather.",
  },
  {
    slug: "hair-care",
    image: catHair,
    alt: "Shop hair care category",
    blurb: "Shampoo, conditioner and oils for stronger hair.",
  },
  {
    slug: "baby-care",
    image: catBaby,
    alt: "Shop mom and baby care category",
    blurb: "Gentle bath, lotion and diapering essentials.",
  },
];


export const Route = createFileRoute("/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(bannersQueryOptions),
  head: () => ({

    meta: [
      { title: "Nills Mart — Genuine Beauty & Skincare Delivered in Bangladesh" },
      {
        name: "description",
        content:
          "Discover deals on skincare, makeup, hair and body care. 100% genuine products, ৳79 Dhaka delivery, bKash and card payments.",
      },
      { property: "og:title", content: "Nills Mart — Genuine Beauty & Skincare in Bangladesh" },
      {
        property: "og:description",
        content: "Deals you cannot miss, top brands and limited time offers on authentic beauty products.",
      },
    ],
  }),
  component: Home,
});

function Rail({ title, to, children }: { title: string; to?: string; children: React.ReactNode }) {
  return (
    <section className="mt-10">
      <div className="mb-3 flex items-baseline justify-between px-4">
        <h2 className="section-title">{title}</h2>
        {to && (
          <Link to={to} className="text-xs font-semibold text-primary">
            View all
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}

function Home() {
  const limited = products.slice(4, 10);
  const { data: banners } = useSuspenseQuery(bannersQueryOptions);
  const heroSlides = byPlacement(banners, "hero");
  const offerSlides = byPlacement(banners, "offer");

  return (
    <div className="mx-auto max-w-5xl">
      <div className="px-2 pt-2 sm:px-4">
        <HeroCarousel slides={heroSlides} />
      </div>



      <section className="mt-8 sm:mt-10">
        <h2 className="section-title mb-3 px-4 text-center text-base sm:mb-5 sm:text-lg lg:text-xl">
          Deals You Cannot Miss
        </h2>
        <OfferTiles slides={offerSlides} />
      </section>



      <section className="mt-10">
        <h2 className="section-title mb-3 px-4 text-center text-base sm:mb-5 sm:text-lg lg:text-xl">
          Top Brands &amp; Offers
        </h2>
        <BrandOfferGrid />
      </section>


      <section className="mt-10">
        <h2 className="section-title mb-3 px-4 text-center text-base sm:mb-5 sm:text-lg lg:text-xl">
          Shop Beauty Products by Category
        </h2>
        <div className="grid grid-cols-2 gap-x-3 gap-y-5 px-4 sm:grid-cols-4 sm:gap-x-4 sm:gap-y-6 sm:px-6 lg:gap-x-5">
          {categoryTiles.map((t) => {
            const count = categoryCount(t.slug);
            return (
              <Link
                key={t.slug}
                to="/category/$slug"
                params={{ slug: t.slug }}
                className="group block min-w-0 transition-transform hover:-translate-y-0.5"
              >
                <div className="wave-tile block">
                  <img
                    src={t.image}
                    alt={t.alt}
                    width={816}
                    height={816}
                    loading="lazy"
                    decoding="async"
                    className="aspect-square w-full object-cover"
                  />
                </div>
                <div className="mt-2 px-0.5 text-center">
                  <div className="flex items-center justify-center gap-1.5">
                    <h3 className="truncate font-display text-sm font-semibold group-hover:text-primary sm:text-base">
                      {categoryBySlug(t.slug)?.name ?? t.slug}
                    </h3>
                    <span className="shrink-0 rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">
                      {count}
                    </span>
                  </div>
                  <p className="mt-0.5 line-clamp-2 text-[11px] leading-snug text-muted-foreground sm:text-xs">
                    {t.blurb}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <Rail title="Limited Time Offers" to="/offers">
        <div className="grid grid-cols-2 gap-3 px-4 sm:grid-cols-3">
          {limited.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </Rail>

      <ConcernTiles />
    </div>
  );
}
