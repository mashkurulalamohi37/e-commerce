import { createFileRoute } from "@tanstack/react-router";

const steps = [
  { title: "Earn", body: "Get 1 point for every ৳100 spent. Points accrue only on successfully completed orders." },
  { title: "Wait", body: "Online order points post within 21 days. Showroom purchases post within 24 hours." },
  { title: "Redeem", body: "Convert points into vouchers, including free-delivery vouchers, at checkout." },
];

export const Route = createFileRoute("/points")({
  head: () => ({
    meta: [
      { title: "Loyalty Points & Vouchers — Nills Mart Bangladesh" },
      { name: "description", content: "Earn 1 point per ৳100 spent and redeem points for vouchers including free delivery." },
      { property: "og:title", content: "Loyalty Points & Vouchers — Nills Mart" },
      { property: "og:description", content: "How earning and redeeming Nills Mart points works." },
    ],
  }),
  component: Points,
});

function Points() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <h1 className="font-display text-2xl font-semibold">Loyalty Points</h1>
      <div className="mt-4 space-y-3">
        {steps.map((s, i) => (
          <div key={s.title} className="rounded-xl border border-border bg-card p-4 shadow-card">
            <p className="font-display text-base font-semibold">
              {i + 1}. {s.title}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
          </div>
        ))}
      </div>
      <div className="mt-6 rounded-xl bg-accent p-4 text-sm text-accent-foreground">
        Points have no cash value and cannot be transferred between accounts.
      </div>
    </div>
  );
}
