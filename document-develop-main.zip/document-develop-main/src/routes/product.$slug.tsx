import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ShieldCheck, Lock, Headphones, Star } from "lucide-react";
import { ProductCard } from "@/components/storefront/ProductCard";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCart } from "@/lib/cart";
import {
  brandName,
  discount,
  productBySlug,
  products,
  taka,
  DELIVERY_INSIDE_DHAKA,
  DELIVERY_OUTSIDE_DHAKA,
} from "@/lib/catalog";

export const Route = createFileRoute("/product/$slug")({
  loader: ({ params }) => {
    const product = productBySlug(params.slug);
    if (!product) throw notFound();
    return product;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.name} — ${brandName(loaderData.brandSlug)} | Nills Mart` },
          { name: "description", content: loaderData.brief.slice(0, 155) },
          { property: "og:title", content: `${loaderData.name} — Nills Mart` },
          { property: "og:description", content: loaderData.brief.slice(0, 155) },
        ]
      : [],
  }),
  component: ProductPage,
});

function ProductPage() {
  const product = Route.useLoaderData();
  const { add } = useCart();
  const off = discount(product);
  const related = products.filter((p) => p.id !== product.id).slice(0, 4);

  return (
    <div className="mx-auto max-w-5xl">
      <nav className="px-4 pt-4 text-xs text-muted-foreground">
        <Link to="/" className="hover:text-primary">
          Home
        </Link>{" "}
        / <Link to="/categories" className="hover:text-primary">{product.categories[0]}</Link> /{" "}
        <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="md:grid md:grid-cols-2 md:gap-8 md:px-4">
        <img
          src={product.image}
          alt={product.name}
          width={800}
          height={800}
          className="mt-3 aspect-square w-full object-cover md:rounded-2xl"
        />

        <div className="px-4 pt-4 md:px-0">
          <p className="text-xs uppercase tracking-widest text-muted-foreground">
            {brandName(product.brandSlug)}
          </p>
          <h1 className="mt-1 font-display text-2xl font-semibold leading-tight">{product.name}</h1>
          <div className="mt-2 flex items-center gap-1 text-sm">
            <Star className="size-4 fill-gold text-gold" />
            <span className="font-semibold">{product.rating.toFixed(1)}</span>
            <span className="text-muted-foreground">({product.reviews} reviews)</span>
          </div>

          <div className="mt-3 flex items-baseline gap-3">
            <span className="text-2xl font-bold">{taka(product.price)}</span>
            <span className="text-sm text-muted-foreground line-through">{taka(product.listPrice)}</span>
            <span className="rounded-full bg-sale px-2 py-0.5 text-xs font-bold text-sale-foreground">
              -{off}%
            </span>
          </div>
          <p className="mt-1 text-sm text-primary">
            You save {taka(product.listPrice - product.price)}
          </p>
          {product.stock <= 6 && (
            <p className="mt-1 text-sm font-medium text-sale">Only {product.stock} items left in stock</p>
          )}

          <dl className="mt-4 grid grid-cols-[110px_1fr] gap-y-1 text-sm">
            <dt className="text-muted-foreground">Size</dt>
            <dd>{product.size}</dd>
            <dt className="text-muted-foreground">SKU</dt>
            <dd>{product.sku}</dd>
            <dt className="text-muted-foreground">Categories</dt>
            <dd>{product.categories.join(", ")}</dd>
            <dt className="text-muted-foreground">Brands</dt>
            <dd>{brandName(product.brandSlug)}</dd>
            <dt className="text-muted-foreground">Brief Description</dt>
            <dd>{product.brief}</dd>
          </dl>

          <div className="mt-5 flex gap-3">
            <Button size="lg" className="flex-1" onClick={() => add(product)}>
              Add to cart
            </Button>
            <Button size="lg" variant="secondary" className="flex-1" onClick={() => add(product)}>
              Buy now
            </Button>
          </div>

          <div className="mt-5 rounded-xl border border-border bg-surface p-4 text-sm">
            <p className="font-semibold">Available Offers</p>
            <ul className="mt-2 list-disc space-y-1 pl-4 text-muted-foreground">
              <li>Earn 1 loyalty point for every ৳100 spent.</li>
              <li>Delivery {taka(DELIVERY_INSIDE_DHAKA)} inside Dhaka, {taka(DELIVERY_OUTSIDE_DHAKA)} outside Dhaka.</li>
              <li>Pay with bKash or any major card.</li>
            </ul>
          </div>

          <ul className="mt-4 grid grid-cols-3 gap-2 text-[11px]">
            {[
              { icon: ShieldCheck, label: "100% Genuine Products" },
              { icon: Lock, label: "100% Secure Payments" },
              { icon: Headphones, label: "Help Center" },
            ].map(({ icon: Icon, label }) => (
              <li
                key={label}
                className="flex flex-col items-center gap-1 rounded-lg border border-border bg-card p-2 text-center font-medium"
              >
                <Icon className="size-4 text-primary" />
                {label}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <Tabs defaultValue="description" className="mt-8 px-4">
        <TabsList className="no-scrollbar w-full justify-start overflow-x-auto">
          <TabsTrigger value="description">Description</TabsTrigger>
          <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
          <TabsTrigger value="how">How To Use</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="qa">Q&amp;A</TabsTrigger>
        </TabsList>
        <TabsContent value="description" className="text-sm text-muted-foreground">
          {product.brief}
        </TabsContent>
        <TabsContent value="ingredients" className="text-sm text-muted-foreground">
          {product.ingredients}
        </TabsContent>
        <TabsContent value="how" className="text-sm text-muted-foreground">
          {product.howToUse}
        </TabsContent>
        <TabsContent value="reviews" className="text-sm text-muted-foreground">
          {product.reviews} verified buyers rated this {product.rating.toFixed(1)} out of 5. Only customers with a
          completed order can post a review.
        </TabsContent>
        <TabsContent value="qa" className="text-sm text-muted-foreground">
          No questions yet. Ask anything about shade, texture or suitability and our beauty advisors will answer.
        </TabsContent>
      </Tabs>

      <section className="mt-10 px-4">
        <h2 className="section-title">You may also like</h2>
        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {related.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
}
