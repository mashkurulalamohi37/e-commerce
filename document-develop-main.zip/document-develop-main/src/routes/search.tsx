import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ProductCard } from "@/components/storefront/ProductCard";
import { Input } from "@/components/ui/input";
import { searchQueryOptions } from "@/lib/search-queries";
import {
  ProductGridSkeleton,
  ProductsEmptyState,
  ProductsErrorState,
} from "@/components/storefront/ProductGridStates";

type SearchParams = { q?: string };

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>): SearchParams => ({
    q: typeof search.q === "string" ? search.q : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Search Beauty Products — Nills Mart Bangladesh" },
      { name: "description", content: "Search authentic skincare, makeup, hair and body care products by name, brand or concern." },
      { property: "og:title", content: "Search Beauty Products — Nills Mart" },
      { property: "og:description", content: "Find the right product by name, brand or skin concern." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SearchPage,
});

const SUGGESTIONS = ["serum", "moisturizer", "lipstick", "hair oil", "sunscreen"];

function SearchPage() {
  const { q = "" } = Route.useSearch();
  const navigate = Route.useNavigate();
  const { data, isPending, isError, isFetching, refetch } = useQuery(searchQueryOptions(q));
  const results = data ?? [];

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="font-display text-2xl font-semibold">Search</h1>
      <Input
        className="mt-3"
        placeholder="Search products, brands or concerns"
        value={q}
        onChange={(e) => navigate({ search: { q: e.target.value || undefined } })}
      />

      {isPending ? (
        <>
          <p className="mt-3 text-sm text-muted-foreground">Searching…</p>
          <ProductGridSkeleton />
        </>
      ) : isError ? (
        <ProductsErrorState onRetry={() => void refetch()} />
      ) : results.length === 0 ? (
        <ProductsEmptyState
          term={q.trim()}
          suggestions={SUGGESTIONS}
          onSuggestion={(s) => navigate({ search: { q: s } })}
        />
      ) : (
        <>
          <p className="mt-3 text-sm text-muted-foreground">
            {results.length} products{isFetching ? " · updating…" : ""}
          </p>
          <div
            className={`mt-3 grid grid-cols-2 gap-3 transition-opacity sm:grid-cols-3 lg:grid-cols-4 ${
              isFetching ? "opacity-60" : "opacity-100"
            }`}
          >
            {results.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
