import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getOrderStatus } from "@/lib/checkout.functions";
import { taka } from "@/lib/catalog";
import { Button } from "@/components/ui/button";

type Search = { order?: string };

export const Route = createFileRoute("/track")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    order: typeof search.order === "string" ? search.order : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Track Your Order — Nills Mart Bangladesh" },
      { name: "description", content: "Check the payment and delivery status of your Nills Mart order by order number." },
      { property: "og:title", content: "Track Your Order — Nills Mart" },
      { property: "og:description", content: "Live payment and delivery status for your Nills Mart order." },
    ],
  }),
  component: Track,
});

function Track() {
  const { order } = Route.useSearch();
  const statusFn = useServerFn(getOrderStatus);

  const query = useQuery({
    queryKey: ["order", order],
    enabled: Boolean(order),
    refetchInterval: 15_000,
    queryFn: () => statusFn({ data: { orderNumber: order! } }),
  });

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <h1 className="font-display text-2xl font-semibold">Order status</h1>
      {!order && <p className="mt-2 text-sm text-muted-foreground">No order number provided.</p>}
      {query.isLoading && <p className="mt-2 text-sm text-muted-foreground">Loading…</p>}
      {query.data && (
        <div className="mt-4 space-y-2 rounded-xl border border-border bg-card p-4 text-sm">
          <p className="font-display text-lg font-semibold">{query.data.order_number}</p>
          <p>
            Payment: <span className="font-semibold capitalize">{query.data.payment_status}</span> via{" "}
            {query.data.payment_method}
          </p>
          <p>
            Delivery: <span className="font-semibold capitalize">{query.data.status}</span> to {query.data.city}
          </p>
          <p className="font-semibold">{taka(query.data.total)}</p>
        </div>
      )}
      {query.isFetched && !query.data && order && (
        <p className="mt-2 text-sm text-muted-foreground">No order found for {order}.</p>
      )}
      <Button asChild variant="secondary" className="mt-6 w-full">
        <Link to="/">Back to store</Link>
      </Button>
    </div>
  );
}
